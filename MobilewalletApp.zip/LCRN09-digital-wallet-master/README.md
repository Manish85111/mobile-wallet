# Let's Code React-Native

## [Watch it on YouTube](http://bit.ly/ByProgrammersYT)

In this episode of "Let’s Code React Native" series, we are going to build a clean looking Digital Wallet app based on the design created by Happy Tri Milliarta on Dribbble.

Be sure to subscribe to our YouTube channel for more videos like this!

## Table of Contents

| Code | Project | Preview | Inspiration | No. of Screens |
| ------ | ------ | ------ | ------ | ------ |
| LCRN09 | [Digital Wallet App](https://youtu.be/rcXyN_cfGY8) | <img src="https://cdn.dribbble.com/users/4208985/screenshots/9730914/media/5eb70ec992c7d1e440e34c76266ea767.png?compress=1&resize=1200x900" width="120" /> | [View](https://dribbble.com/shots/9730914-Wallie-Digital-Wallet) | 3 |

## Credits
Credits to REST Countries API for this awesome API. Check them out here: https://restcountries.com/

## Contributors

<a href="https://github.com/byprogrammers/lets-code-react-native/graphs/contributors">
  <img src="https://contributors-img.web.app/image?repo=byprogrammers/lets-code-react-native" />
</a>

